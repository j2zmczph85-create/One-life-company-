const authScreen=document.getElementById("authScreen"),appScreen=document.getElementById("appScreen"),loginForm=document.getElementById("loginForm"),signupForm=document.getElementById("signupForm"),login=document.getElementById("login"),signup=document.getElementById("signup"),showSignup=document.getElementById("showSignup"),showLogin=document.getElementById("showLogin"),loginMessage=document.getElementById("loginMessage"),signupMessage=document.getElementById("signupMessage"),logoutBtn=document.getElementById("logoutBtn"),welcomeText=document.getElementById("welcomeText");

showSignup.addEventListener("click",()=>{loginForm.classList.add("hidden");signupForm.classList.remove("hidden");loginMessage.textContent="";signupMessage.textContent=""});
showLogin.addEventListener("click",()=>{signupForm.classList.add("hidden");loginForm.classList.remove("hidden");loginMessage.textContent="";signupMessage.textContent=""});

document.querySelectorAll(".show-password").forEach(button=>button.addEventListener("click",()=>{const input=document.getElementById(button.dataset.target);if(input.type==="password"){input.type="text";button.textContent="Hide"}else{input.type="password";button.textContent="Show"}}));

function getUsers(){try{return JSON.parse(localStorage.getItem("oneLifeUsers")||"[]")}catch{return[]}}
function saveUsers(users){localStorage.setItem("oneLifeUsers",JSON.stringify(users))}

signup.addEventListener("submit",event=>{event.preventDefault();const name=document.getElementById("signupName").value.trim(),email=document.getElementById("signupEmail").value.trim().toLowerCase(),password=document.getElementById("signupPassword").value,confirm=document.getElementById("signupConfirm").value;signupMessage.textContent="";if(password.length<6){signupMessage.textContent="Password must contain at least 6 characters.";return}if(password!==confirm){signupMessage.textContent="Passwords do not match.";return}const users=getUsers();if(users.some(user=>user.email===email)){signupMessage.textContent="An account with this email already exists.";return}const user={id:Date.now(),name,email,password,createdAt:new Date().toISOString()};users.push(user);saveUsers(users);localStorage.setItem("oneLifeCurrentUser",JSON.stringify({id:user.id,name:user.name,email:user.email}));signup.reset();showApp(user)});

login.addEventListener("submit",event=>{event.preventDefault();const email=document.getElementById("loginEmail").value.trim().toLowerCase(),password=document.getElementById("loginPassword").value;loginMessage.textContent="";const user=getUsers().find(user=>user.email===email&&user.password===password);if(!user){loginMessage.textContent="Incorrect email or password.";return}localStorage.setItem("oneLifeCurrentUser",JSON.stringify({id:user.id,name:user.name,email:user.email}));login.reset();showApp(user)});

function showApp(user){authScreen.classList.add("hidden");appScreen.classList.remove("hidden");welcomeText.textContent=`Welcome, ${user.name}`}
logoutBtn.addEventListener("click",()=>{localStorage.removeItem("oneLifeCurrentUser");appScreen.classList.add("hidden");authScreen.classList.remove("hidden");loginForm.classList.remove("hidden");signupForm.classList.add("hidden")});

function checkLogin(){const saved=localStorage.getItem("oneLifeCurrentUser");if(!saved)return;try{const user=JSON.parse(saved);if(user&&user.id)showApp(user)}catch{localStorage.removeItem("oneLifeCurrentUser")}}
checkLogin();
